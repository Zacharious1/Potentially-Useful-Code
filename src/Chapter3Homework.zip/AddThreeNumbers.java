//Help Received: none
import java.util.Scanner;
public class AddThreeNumbers {
    public static void main(String[] args) {
        int a = 1 + (int) (Math.random() * 9);
        int b = 1 + (int) (Math.random() * 9);
        int c = 1 + (int) (Math.random() * 9);

        System.out.println(a +"+"+ b +"+"+ c);

        Scanner sc = new Scanner(System.in);
        int ans = a + b + c;
        System.out.println("What is the answer? ");
        int userAns = sc.nextInt();

        if (ans == userAns) {
            System.out.println("Correct");
        }
        else
            System.out.println("Incorrect");

    }
}
