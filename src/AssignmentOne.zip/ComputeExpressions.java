public class ComputeExpressions 
{
	public static void main(String[] args)
	{
		System.out.print(" (9.5 * 4.5 - 2.5 * 3) / (45 - 3.5) = ");
		System.out.print((9.5 * 4.5 - 2.5 * 3) / (45.5 - 3.5));
	}
}
