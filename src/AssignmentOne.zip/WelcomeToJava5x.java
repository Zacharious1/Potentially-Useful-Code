public class WelcomeToJava5x 
{
	public static void main(String[] args)
	{

		for (int a=0; a<5; a++) 
		{
			System.out.println("Welcome To Java");
		}
	}
}
//Help Received: None