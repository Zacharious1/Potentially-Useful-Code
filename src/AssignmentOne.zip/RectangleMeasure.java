public class RectangleMeasure
{
	static double perimeter;
	static double area;
	static double length = 4.5;
	static double height = 7.9;



	public static void main(String[] args) 
	{
		perimeter = (2.0 * length + 2.0 * height);
		area = (length * height);

		System.out.println("Perimeter is: " + perimeter);
		System.out.println("Area is: " + area);
		
	}
}
//Help Received: None


/*
import java.util.Scanner;

//more complex solution with user-inputed values


public class RectangleMeasure 
{
	static Scanner sc = new Scanner(System.in);
	 static double Length;
	 static double Height;

	  static double perimeter;
	  static double area;
	public static void main(String[] args)
	{
		System.out.println("Enter length then press enter ");
		Length=sc.nextDouble();
		System.out.println("Enter height then press enter ");
		Height=sc.nextDouble();

		perimeter = (2.0 * Length + 2.0 * Height);
		area = (Length * Height);


		System.out.println("Perimeter is: " + perimeter);
		System.out.println("Area is: " + area);
	}
}
//Help Received: Mr. Van Leer helped me learn how to use scanner utility
 */
 