import socket

from threading import Thread
import time

class PrintA(Thread):
    def __init__(self):
        Thread.__init__(self)
        self.running = True
    def run(self):
        port = 8085
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # Accept UDP datagrams, on the given port, from any sender
        s.bind(("", port))
        print("waiting on port:\n", port);
        while self.running:
            # Receive up to 1,024 bytes in a datagram
            data, addr = s.recvfrom(1024)
            print("received:", data, "from", addr);
    def stop(self):
        self.running = False

class PrintB(Thread):
    def __init__(self):
        Thread.__init__(self)
        self.running = True
    def run(self):
        port = 8085
        host= "cis301hw4-host2.ddns.net"
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # Accept UDP datagrams, on the given port, from any sender
        #val=input("Enter your message or Q to exit\n")
        while self.running:
            val = input("Enter your message or Q to exit\n")
            s.sendto(val.encode(),(host,port))
            print("Message Sent!")
    def stop(self):
        self.running = False

a = PrintA()
b = PrintB()

a.start()
b.start()
