//Help Received: None
public class VehiclePlateNumbers {
    public static void main(String[] args) {
        char one = (char) (65 + (Math.random() * 26));
        char two = (char) (65 + (Math.random() * 26));
        char three = (char) (65 + (Math.random() * 26));
        int four = (int) (1 + (Math.random() * 10));
        int five = (int) (1 + (Math.random() * 10));
        int six = (int) (1 + (Math.random() * 10));
        int seven = (int) (1 + (Math.random() * 10));
        System.out.print(one + " " + two + " " + three + " " + four + " " + five + " " + six + " " + seven);






    }
}
